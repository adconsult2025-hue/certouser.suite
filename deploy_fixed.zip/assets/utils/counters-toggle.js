/**
 * Minimal counters toggle:
 *  - Add a button with id="toggle-counters"
 *  - Wrap counters sections with class="counters-section"
 *  - Hidden by default via CSS; this script toggles them.
 */
(function () {
  function toggle() {
    document.querySelectorAll('.counters-section').forEach(el => {
      const current = getComputedStyle(el).display;
      el.style.display = (current === 'none') ? '' : 'none';
    });
  }
  document.addEventListener('DOMContentLoaded', () => {
    const btn = document.getElementById('toggle-counters');
    if (btn) btn.addEventListener('click', toggle);
  });
})();
