# Integrazioni aggiunte — 2025-09-26 07:19

Questo pacchetto include:
1. **Netlify Functions**
   - `netlify/functions/_db.js`: helper condiviso (Neon/Postgres).
   - `netlify/functions/migrate-add-cabina.js`: migrazione idempotente per colonna `cabina` su `customers`.
   - `netlify/functions/cer-create.js`: endpoint POST per creare una CER.

2. **Netlify config**
   - `netlify.toml`: aggiunto redirect SPA (`/* -> /index.html`) e directory funzioni + CORS per `/.netlify/functions/*`.

3. **Toggle CONTATORI**
   - `assets/utils/counters-toggle.js` + `assets/css/counters.css`.
   - Come usare: aggiungi un bottone `<button id="toggle-counters">CONTATORI</button>` e attribuisci `class="counters-section"` ai blocchi contatori. Saranno nascosti finché non clicchi il bottone.

## Endpoint disponibili
- **Migrazione**: `GET https://<site>/.netlify/functions/migrate-add-cabina`
- **Crea CER**: `POST https://<site>/.netlify/functions/cer-create`
  ```json
  {
    "nome": "CER Ponte Grande",
    "cabina": "FR001-XYZ",
    "quota_condivisa": 0.35,
    "split_produttore": 0.55,
    "split_cer": 0.15,
    "trader": "Omnia X"
  }
  ```

> Nota: Imposta `NEON_DATABASE_URL` (o `DATABASE_URL`) nelle variabili del sito Netlify. Se le env superano 4KB, sposta chiavi lunghe su Netlify Secrets o usa un `.env` lato build non caricato nelle funzioni.

## Wire-up rapido nel front-end
Inserisci nel layout principale:
```html
<link rel="stylesheet" href="/assets/css/counters.css">
<script defer src="/assets/utils/counters-toggle.js"></script>
```
Aggiungi il bottone dove preferisci (es. header della dashboard):
```html
<button id="toggle-counters" class="btn ghost">CONTATORI</button>
```
Racchiudi i blocchi contatori:
```html
<section class="counters-section"> ... </section>
```

Per salvare una CER dal form esistente (es. `crea.html`):
```js
async function salvaCER(payload) {
  const res = await fetch('/.netlify/functions/cer-create', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Errore salvataggio CER');
  return data.cer;
}
```

## File originali rilevati
Sono stati rilevati 6 file complessivi nel pacchetto d'origine.
