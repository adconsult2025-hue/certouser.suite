// Script to dynamically add a link to the simulator page in the existing navigation bar.
// This script waits until a <nav> with a <ul> is present in the DOM, then appends
// a new list item linking to the simulatore.html page if it does not already exist.
(function() {
  function addSimLink() {
    const nav = document.querySelector('nav');
    if (!nav) return false;
    const ul = nav.querySelector('ul');
    if (!ul) return false;
    // Check if a link to the simulator already exists
    const existing = ul.querySelector('a[href$="simulatore.html"]');
    if (existing) return true;
    // Create the new list item and link
    const li = document.createElement('li');
    const a = document.createElement('a');
    a.href = 'simulatore.html';
    a.textContent = 'Simulatore';
    li.appendChild(a);
    ul.appendChild(li);
    return true;
  }
  // Try to add the link immediately; if it fails, observe the DOM for nav insertion
  if (!addSimLink()) {
    const observer = new MutationObserver(() => {
      if (addSimLink()) {
        observer.disconnect();
      }
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }
})();