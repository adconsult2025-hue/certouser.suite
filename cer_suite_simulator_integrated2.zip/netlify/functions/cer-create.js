const { withClient, success, failure } = require('./_db');

function jsonBody(event) {
  if (!event.body) return {};
  try { return JSON.parse(event.body); } catch { return {}; }
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers: { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type, Authorization' } };
  }
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }
  const data = jsonBody(event);
  const required = ['nome', 'cabina', 'quota_condivisa', 'split_produttore', 'split_cer', 'trader'];
  const missing = required.filter(k => data[k] == null || data[k] === '');
  if (missing.length) return failure('Campi mancanti: ' + missing.join(', '), 400);

  try {
    return await withClient(async (client) => {
      await client.query(`
        CREATE TABLE IF NOT EXISTS cer (
          id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
          nome text NOT NULL,
          cabina text NOT NULL,
          quota_condivisa numeric NOT NULL,
          split_produttore numeric NOT NULL,
          split_cer numeric NOT NULL,
          trader text,
          created_at timestamptz DEFAULT now()
        );
      `);
      const ins = await client.query(
        `INSERT INTO cer (nome, cabina, quota_condivisa, split_produttore, split_cer, trader)
         VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
        [data.nome, data.cabina, data.quota_condivisa, data.split_produttore, data.split_cer, data.trader || null]
      );
      return success({ ok: true, cer: ins.rows[0] }, 201);
    });
  } catch (e) {
    return failure(e.message);
  }
};
