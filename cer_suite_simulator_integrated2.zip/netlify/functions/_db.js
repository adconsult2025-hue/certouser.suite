// Shared DB helper for Netlify Functions (Neon/Postgres)
const { Client } = require('pg');

function success(body, code = 200) {
  return {
    statusCode: code,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  };
}

function failure(msg, code = 500, extra = {}) {
  return {
    statusCode: code,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ error: msg, ...extra }),
  };
}

function getDbUrl() {
  const url =
    process.env.NEON_DATABASE_URL ||
    process.env.DATABASE_URL ||
    process.env.NETLIFY_DATABASE_URL ||
    process.env.NETLIFY_DATABASE_URL_UNPOOLED;

  if (!url) throw new Error('NEON_DATABASE_URL / DATABASE_URL non impostato');
  return url;
}

async function withClient(fn) {
  const client = new Client({ connectionString: getDbUrl(), ssl: { rejectUnauthorized: false } });
  await client.connect();
  try {
    return await fn(client);
  } finally {
    await client.end();
  }
}

module.exports = { withClient, success, failure };
