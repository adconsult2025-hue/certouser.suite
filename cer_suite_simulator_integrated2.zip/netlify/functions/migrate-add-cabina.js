const { withClient, success, failure } = require('./_db');

exports.handler = async () => {
  try {
    return await withClient(async (client) => {
      await client.query(`
        CREATE TABLE IF NOT EXISTS customers (
          id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
          name text
        );
      `);
      await client.query(`
        ALTER TABLE customers
        ADD COLUMN IF NOT EXISTS cabina text;
      `);
      return success({ ok: true, migrated: true });
    });
  } catch (e) {
    return failure(e.message);
  }
};
